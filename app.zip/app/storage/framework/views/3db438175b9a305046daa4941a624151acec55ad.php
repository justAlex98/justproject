<?php $__env->startSection('content'); ?>
<div class="container text-center">
  <h2>Get confirmation link</h2>
  <form action="<?php echo e(route('send-confirmation-email',$user)); ?>" method="post">
  	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e($user->email); ?>" name='email'>
	<input type="submit" class='btn btn-primary' value='Send!'>

  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* H:\xampp\htdocs\app\resources\views/request-email-confirmation.blade.php */ ?>