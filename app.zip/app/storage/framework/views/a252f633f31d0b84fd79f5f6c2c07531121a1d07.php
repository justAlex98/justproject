<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($list['title']); ?></title>
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/style.css">
</head>
<body>
    




<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="list_film col-xl-9 col-lg-9">
    <?php $__currentLoopData = $list['film']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="film row">
        <div class="col-xl-3 col-lg-3">
        <img src="http://127.0.0.1:8000/img/<?php echo e($f->picture); ?>" alt="Hahaha" >
        </div>
        <div class="col-xl-9 col-lg-9 film_info">
           <h2>Назва: <a href="http://127.0.0.1:8000/film/<?php echo e($f->id); ?>"><?php echo e($f->title); ?></a></h2>
           <h4>Оригінальна назва: <?php echo e($f->subtitle); ?></h4>
           <p>Категорія: <?php echo e($f->category); ?> </p>
            <p>Контент: <?php echo e($f->content); ?></p>
            <?php if($list['favore']): ?>
            <form action="<?php echo e(route('deletmyfavore')); ?>" method='post'>
            <?php echo e(csrf_field()); ?>

                <input type="hidden" value='<?php echo e($f->id); ?>' name='film_id'>
                <input type="hidden" value='<?php echo e(Auth::user()->id); ?>' name='user_id'>
                <input type="submit" class='btn btn-primary favore' value='Видалити з вподобань'>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
     <div class="category col-xl-3 col-lg-3">
        <h1>Категорії</h1>
        <div class="list_category">
        <ul>
        <?php $__currentLoopData = $list['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="http://127.0.0.1:8000/category/<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* H:\xampp\htdocs\app\resources\views/category.blade.php */ ?>