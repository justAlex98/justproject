<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
</head>
<body>
<h1>Для підтвертження вашого емайла натисніть</h1>
<a href="<?php echo e(route('confirm-email',[$user,$token])); ?>">Натисніть тут</a>
	
</body>
</html>
<?php /* H:\xampp\htdocs\app\resources\views/mail.blade.php */ ?>