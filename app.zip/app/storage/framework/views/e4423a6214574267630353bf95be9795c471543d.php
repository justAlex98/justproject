<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($list['film']->title); ?></title>
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/style.css">
</head>
<body>
    




<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="list_film col-xl-9 col-lg-9">
        <div class="film row">
        <div class="col-xl-3 col-lg-3">
        <img src="http://127.0.0.1:8000/img/<?php echo e($list['film']->picture); ?>" alt="Hahaha" ></div>
        <div class="film_info col-xl-9 col-lg-9">
           <h2>Назва: <?php echo e($list['film']->title); ?></h2>
           <h4>Оригінальна назва: <?php echo e($list['film']->subtitle); ?></h4>
           <p>Категорія: <?php echo e($list['film']->category); ?> </p>
            <p>Контент: <?php echo e($list['film']->content); ?></p>
             <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        <form action="<?php echo e(route('myfavorite',[Auth::user(),$list['film']])); ?>" method="get">
        <?php echo e(csrf_field()); ?>

            <input type="hidden" value="<?php echo e($list['film']->id); ?>" name='film_id'>
            <input type="submit" class='btn btn-primary favore' value='Додати до вподобань'>
        </form>
        <?php endif; ?>
        </div>
        </div>
        <iframe class='trailer' width="560" height="315" src="<?php echo e($list['film']->trailer); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="category col-xl-3 col-lg-3">
        <h1>Категорії</h1>
        <div class="list_category">
        <ul>
        <?php $__currentLoopData = $list['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="http://127.0.0.1:8000/category/<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
    </div>
</div>
</div>



</div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* H:\xampp\htdocs\app\resources\views/film.blade.php */ ?>