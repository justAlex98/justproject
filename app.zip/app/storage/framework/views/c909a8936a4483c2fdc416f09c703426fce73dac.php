<div class="category col-xl-3 col-lg-3">
    <h1>Категорії</h1>
    <div class="list_category">
    <ul>
    <?php $__currentLoopData = $list['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="http://127.0.0.1:8000/category/<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
</div>
<?php /* H:\xampp\htdocs\app\resources\views/cat.blade.php */ ?>