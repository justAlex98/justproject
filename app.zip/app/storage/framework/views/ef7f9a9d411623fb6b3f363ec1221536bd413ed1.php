
<?php /* H:\xampp\htdocs\app\resources\views/favorite.blade.php */ ?>