<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{$list['film']->title}}</title>
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/style.css">
</head>
<body>
    

@extends('layouts.app')


@section('content')
<div class="container">
<div class="row">
    <div class="list_film col-xl-9 col-lg-9">
        <div class="film row">
        <div class="col-xl-3 col-lg-3">
        <img src="http://127.0.0.1:8000/img/{{$list['film']->picture}}" alt="Hahaha" ></div>
        <div class="film_info col-xl-9 col-lg-9">
           <h2>Назва: {{$list['film']->title}}</h2>
           <h4>Оригінальна назва: {{$list['film']->subtitle}}</h4>
           <p>Категорія: {{$list['film']->category}} </p>
            <p>Контент: {{$list['film']->content}}</p>
             @guest
        @else
        <form action="{{route('myfavorite',[Auth::user(),$list['film']])}}" method="get">
        {{ csrf_field() }}
            <input type="hidden" value="{{$list['film']->id}}" name='film_id'>
            <input type="submit" class='btn btn-primary favore' value='Додати до вподобань'>
        </form>
        @endguest
        </div>
        </div>
        <iframe class='trailer' width="560" height="315" src="{{$list['film']->trailer}}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="category col-xl-3 col-lg-3">
        <h1>Категорії</h1>
        <div class="list_category">
        <ul>
        @foreach($list['category'] as $cat)
            <li><a href="http://127.0.0.1:8000/category/{{$cat->name}}">{{$cat->name}}</a></li>
        @endforeach
        </ul>
        </div>
    </div>
</div>
</div>



</div>
@endsection
</body>
</html>