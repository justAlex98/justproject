<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{$list['title']}}</title>
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/style.css">
</head>
<body>
    

@extends('layouts.app')


@section('content')
<div class="container">
<div class="row">
    <div class="list_film col-xl-9 col-lg-9">
    @foreach($list['film'] as $f)
    <div class="film row">
        <div class="col-xl-3 col-lg-3">
        <img src="http://127.0.0.1:8000/img/{{$f->picture}}" alt="Hahaha" >
        </div>
        <div class="col-xl-9 col-lg-9 film_info">
           <h2>Назва: <a href="http://127.0.0.1:8000/film/{{$f->id}}">{{$f->title}}</a></h2>
           <h4>Оригінальна назва: {{$f->subtitle}}</h4>
           <p>Категорія: {{$f->category}} </p>
            <p>Контент: {{$f->content}}</p>
            @if($list['favore'])
            <form action="{{route('deletmyfavore')}}" method='post'>
            {{ csrf_field() }}
                <input type="hidden" value='{{$f->id}}' name='film_id'>
                <input type="hidden" value='{{Auth::user()->id}}' name='user_id'>
                <input type="submit" class='btn btn-primary favore' value='Видалити з вподобань'>
            </form>
            @endif
        </div>
    </div>
    <hr>
    <br>
    @endforeach
    </div>
     <div class="category col-xl-3 col-lg-3">
        <h1>Категорії</h1>
        <div class="list_category">
        <ul>
        @foreach($list['category'] as $cat)
            <li><a href="http://127.0.0.1:8000/category/{{$cat->name}}">{{$cat->name}}</a></li>
        @endforeach
        </ul>
        </div>
    </div>
</div>

</div>

@endsection
</body>
</html>