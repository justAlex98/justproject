<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
</head>
<body>
<h1>Для підтвертження вашого емайла натисніть</h1>
<a href="{{ route('confirm-email',[$user,$token])}}">Натисніть тут</a>
	
</body>
</html>