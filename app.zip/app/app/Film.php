<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Film extends Model
{
   public static function category($cat){
   	 return static::where('category',$cat)->get();
   }
}
