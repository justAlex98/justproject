<?php

namespace App;
use Illuminate\Support\Str;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Hash;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     *//*
    protected $fillable = [
        'name', 'email', 'password','phone',
    ];*/
    protected $guarded=[];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    public function confirmed(){
        return !! $this->is_confirmed;
    }
    public function getEmailConfirmationToken(){
        $token=Str::random();
        $this->update(['confirmation_token'=>$token]);
        return $token;

    }
    public function confirm(){
        $this->update([
            'is_confirmed'=>true,
            'confirmation_token'=> null,
            ]);
        return $this;
    }
    public function change_info($data){
        if($data->name  && $this->name!== $data->name){
            $this->update(['name'=>$data->name]);
        }
        if($data->email  && $this->email!== $data->email){
            $this->update(['email'=>$data->email]);
        }
        if($data->phone  && $this->phone!== $data->phone){
            $this->update(['phone'=>$data->phone]);
        }
        if($data->birthday && $this->birthday!== $data->birthday){
            $this->update(['birthday'=>$data->birthday]);
        }
        if($data->password && $data->password==$data->password_confirmation  && $this->password!== Hash::make($data->password)){
            $this->update(['password'=>Hash::make($data->password)]);
        }
        return $this;
    } 
}
