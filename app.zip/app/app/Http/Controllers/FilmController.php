<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Film;
use App\Category;
use App\User;
use App\Myfavore;

class FilmController extends Controller
{
    public function index(){
    	$list=[
    		'film'=>Film::all(),
    		'category'=>Category::all(),
    		'title'=>'Фільми',
            'favore'=>false,
    	];
    	return view('category',compact('list'));
    }
    public function filter($cat){
    	$list=[
    		'film'=>Film::category($cat),
    		'category'=>Category::all(),
    		'title'=>$cat,
            'favore'=>false,
    	];
    	return view('category',compact('list'));
    }
    public function show($id){
    	$list=[
    		'film'=>Film::find($id),
    		'category'=>Category::all(),
    	];
    	return view('film',compact('list'));
    }
    public function find($array){
        $favore=array();
        foreach($array as $a){
            array_push($favore,Film::find($a->film_id));
        }
        return $favore;
    }
    public function myfavorite($user){
        $favore=$this->find(MyFavore::all()->where('user_id',$user));
        $list=[
            'film'=>$favore,
            'category'=>Category::all(),
            'title'=>'Вподобання',
            'favore'=>true,
        ];
        return view('category',compact('list'));
    }
    public function add(User $user,Film $film){
        if(!MyFavore::where('film_id',$film->id)->where('.user_id',$user->id)->first()){
        return MyFavore::create([
            'name' => $film->title,
            'film_id' => $film->id,
            'user_id' => $user->id,
        ]);
        }
    }
    public function addMyFavorite(User $user,Film $film){
        $this->add($user,$film);
        return redirect()->route('home',$user);
    }
    public function deletMyFavorite(Request $request){
        $film=Myfavore::where('film_id',$request->film_id)->where('user_id',$request->user_id)->first();
        if($film){$film->delete();}
        return redirect()->route('home',$request->user_id);
    }
}
