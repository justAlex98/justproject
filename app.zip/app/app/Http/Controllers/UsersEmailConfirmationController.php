<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
Use App\Mail\EmailConfirmation;
use Illuminate\Support\Facades\Mail;

class UsersEmailConfirmationController extends Controller
{
    public function request(User $user){
    	if($user->confirmed()){
    		return redirect()->route('home',$user);
    	}
    	return view('request-email-confirmation',compact('user'));
    }
    public function sendEmail(User $user,Request $request){
    	$token=$user->getEmailConfirmationToken();
    	Mail::to($user->email)->send(new EmailConfirmation($user,$token));
        return redirect()->route('home',$user);
    }
    public function confirm(User $user,$token){
    	$userToConform=User::where('email',$user->email)->where('.confirmation_token',$token)->first();
    	if(!$userToConform){
    		return redirect()->route('request-confirm-email',$user);
    	}
    	$userToConform->confirm();
    	return redirect()->route('home',$user);
    }
}
