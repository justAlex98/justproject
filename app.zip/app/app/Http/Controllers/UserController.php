<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use\Auth;

class UserController extends Controller
{
    public function index(){
    	$user=Auth::user();
    	return view('profile',compact('user'));
    }
    public function profile(User $user,Request $request ){
    	$user->change_info($request);
    	return redirect()->route('profile');
    }
}
