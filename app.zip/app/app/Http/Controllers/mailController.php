<?php

namespace App\Http\Controllers;
use Mail;
use Illuminate\Http\Request;

class mailController extends Controller
{
    public function send(){
    	Mail::send(['text'=>'mail'],['name','Alex'],function($message){
    		$message->to('lexf0002@gmail.com','To User')->subject('Test emil');
    		$message->from('lexf0002@gmail.com','From admin');
    	});
    }
}
