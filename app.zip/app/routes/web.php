<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
Route::get('/send', 'mailController@send');
Route::get('/','FilmController@index');
Route::get('/home','FilmController@index')->middleware(['auth','confirmed']);
Route::get('/film/{id}','FilmController@show');
Route::get('category/{category}','FilmController@filter');
Route::get('/home/{user}','FilmController@myfavorite')->name('home')->middleware(['auth','confirmed']);
Route::get('users/{user}/request-confirmation','UsersEmailConfirmationController@request')->name('request-confirm-email')->middleware('auth');
Route::post('users/{user}/send-confirmation-email','UsersEmailConfirmationController@sendEmail')->name('send-confirmation-email')->middleware('auth');
Route::get('users/{user}/confirm-email/{token}','UsersEmailConfirmationController@confirm')->name('confirm-email');
Route::get('users/{user}/myfavorite/{film}','FilmController@addMyFavorite')->name('myfavorite');
Route::get('/profile','UserController@index')->middleware(['auth','confirmed'])->name('profile');
Route::post('/profile/update/{user}','UserController@profile')->middleware(['auth','confirmed'])->name('profile-update');
Route::post('/delet','FilmController@deletMyFavorite')->middleware('auth')->name('deletmyfavore');